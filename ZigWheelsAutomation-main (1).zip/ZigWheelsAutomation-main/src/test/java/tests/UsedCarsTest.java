package tests;

import java.util.List;
import org.testng.Assert;
import org.testng.annotations.Test;
import base.baseTest;
import pages.HomePage;
import pages.UsedCarsPage;

public class UsedCarsTest extends baseTest {

    @Test
    public void verifyPopularUsedCarsInChennai() {
        // Step 1: Navigate to Used Cars in Chennai from Home Page
        HomePage homePage = new HomePage(driver);
        homePage.navigateToUsedCarsInChennai();

        // Step 2: Perform actions on Used Cars Page
        UsedCarsPage usedCarsPage = new UsedCarsPage(driver);

        // Step 3: Extract popular used car models
        List<String> popularCars = usedCarsPage.getPopularUsedCarModels();

        // Step 4: Validations
        Assert.assertNotNull(popularCars, "Used car list is null");
        Assert.assertTrue(!popularCars.isEmpty(), "No popular used cars found for Chennai");

        System.out.println("Total Popular Used Cars Found: " + popularCars.size());
    }
}
