package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.baseTest;
import pages.HomePage;
import pages.LoginPage;

public class LoginTest extends baseTest {

    @Test
    public void verifyInvalidGoogleLogin() {
        HomePage homePage = new HomePage(driver);
        homePage.clickGoogleLogin();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.switchToGoogleLoginWindow();

        String errorMessage = loginPage.loginWithInvalidGoogleAccount("invalidemail123@gmail.com");

        Assert.assertTrue(errorMessage != null && !errorMessage.trim().isEmpty(), "Google login failure was not detected");

        System.out.println("Captured Login Failure Message:");
        System.out.println(errorMessage);
    }
}