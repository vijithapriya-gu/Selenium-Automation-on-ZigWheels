package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.baseTest;
import pages.HomePage;
import pages.UpcomingBikesPage;

public class UpcomingBikesTest extends baseTest {

    @Test
    public void verifyUpcomingHondaBikes() {
        HomePage homePage = new HomePage(driver);
        homePage.navigateToUpcomingBikes();

        UpcomingBikesPage bikesPage = new UpcomingBikesPage(driver);

        bikesPage.clickHondaFilter();
        bikesPage.clickViewMoreBikesIfPresent();

        int totalBikes = bikesPage.displayAndStoreAllUpcomingHondaBikes();
        Assert.assertTrue(totalBikes >= 1, "No upcoming Honda bikes were displayed");
    }
}