package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;
import utils.ApacheUtils;

public class UpcomingBikesPage {
    private WebDriver driver;
    private WaitUtils wait;
    private JavascriptExecutor js;

    public UpcomingBikesPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WaitUtils(driver);
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

//    LOCATORS
    private By hondaFilter = By.xpath("//li[101]/div/div/div/div/div/ul/li[5]/a");
    private By viewMoreBikes = By.xpath("//span[contains(text(),'View More')]");
    private By bikeNames = By.xpath("//strong[contains(@class,'lnk-hvr') and contains(@class,'txt-ulne')]");
    private By bikePrices = By.xpath("//div[contains(@class,'b') and contains(@class,'fnt-15')]");
    private By launchDates = By.xpath("//div[contains(@class,'clr-try') and contains(@class,'fnt-14')]");

//    PAGE ACTIONS
    public void clickHondaFilter() {
        js.executeScript("window.scrollBy(0,600);");
        WebElement honda = wait.waitForElementVisible(hondaFilter);
        js.executeScript("arguments[0].click();", honda);
    }

    public void clickViewMoreBikesIfPresent() {
        List<WebElement> buttons = driver.findElements(viewMoreBikes);
        if (!buttons.isEmpty()) {
            js.executeScript("arguments[0].click();", buttons.get(0));
        }
    }

    public String extractPriceInLakhs(String priceText) {
        try {
            if (priceText == null || priceText.isEmpty()) {
                return "-1";
            }
            priceText = priceText.toLowerCase();

            // Case 1: Price in Lakhs
            if (priceText.contains("lakh")) {
                String temp = priceText.replaceAll("[^0-9.]", "");
                String res = temp.substring(1);
                return res;
            }
            // Case 2: Price in thousands / rupees
            if (priceText.contains(",")) {
                double rupees = Double.parseDouble(priceText.replaceAll("[^0-9]", ""));
                double db = rupees / 100000; // convert to lakhs
                return Double.toString(db);
            }
        } catch (Exception e) {
            return "-1";
        }
        return "-1";
    }

//    Displays & stores ALL Honda upcoming bikes (≈17)
    public int displayAndStoreAllUpcomingHondaBikes() {
        ApacheUtils ap = new ApacheUtils("All Upcoming Honda Bikes Under 4Lac");

        // Excel headers
        ap.writeXL("Bike Name", 0, 0);
        ap.writeXL("Price", 0, 1);
        ap.writeXL("Expected Launch", 0, 2);

        List<WebElement> names = driver.findElements(bikeNames);
        List<WebElement> prices = driver.findElements(bikePrices);
        List<WebElement> dates = driver.findElements(launchDates);

        int total = Math.min(
                names.size(),
                Math.min(prices.size(), dates.size())
        );

        int row = 1;
        System.out.println("ALL Upcoming Honda Bikes Under 4Lac");
        System.out.println("------------------------------------------------");

        for (int i = 0; i < total; i++) {
            String name = names.get(i).getText();
            String price = extractPriceInLakhs(prices.get(i).getText());
            String launchDate = dates.get(i).getText();
            double doublePrice = Double.parseDouble(price);
            if(doublePrice > 0 && doublePrice<4.0){
                // Console output
                System.out.println("Bike Name       : " + name);
                System.out.println("Price           : " + prices.get(i).getText());
                System.out.println("Expected Launch : " + launchDate.substring(18));
                System.out.println("------------------------------------------");

                // Excel output
                ap.writeXL(name, row, 0);
                ap.writeXL(prices.get(i).getText(), row, 1);
                ap.writeXL(launchDate.substring(18), row, 2);
                row++;
            }
        }

        String filePath = System.getProperty("user.dir") + "/src/main/resources/UpcomingBikes.xlsx";
        ap.saveAndClose(filePath);
        return total;
    }
}



