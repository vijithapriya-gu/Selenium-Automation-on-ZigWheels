package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utils.WaitUtils;

public class LoginPage {
    private WebDriver driver;
    private WaitUtils wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

//    Locators
    private By emailInput = By.id("identifierId");
    private By nextButton = By.xpath("//span[text()='Next']");

//    Error variants (may or may not appear)
    private By invalidAccountError = By.xpath("//div[contains(@class,'Ekjuhf') and contains(@class,'Jj6Lae')]");
    private By blockedLoginError = By.xpath("//div[contains(@class,'vAV9bf')]");

//    Actions
//    Switch to latest window
    public void switchToGoogleLoginWindow() {
        for (String window : driver.getWindowHandles()) {
            driver.switchTo().window(window);
        }
    }

//    Perform invalid login and capture error safely
    public String loginWithInvalidGoogleAccount(String invalidEmail) {
        wait.waitForElementVisible(emailInput).sendKeys(invalidEmail);
        wait.waitForElementClickable(nextButton).click();

        // Small wait for redirect / security flow
        WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(5));

        // Try DOM-based error (invalid account)
        try {
            WebElement error = shortWait.until(ExpectedConditions.visibilityOfElementLocated(invalidAccountError));
            return error.getText();
        } catch (Exception ignored) {}

        // Try DOM-based error (blocked browser)
        try {
            WebElement error = shortWait.until(ExpectedConditions.visibilityOfElementLocated(blockedLoginError));
            return error.getText();
        } catch (Exception ignored) {}

        // Fallback: detect by URL or title (MOST RELIABLE)
        String currentUrl = driver.getCurrentUrl();
        String title = driver.getTitle();

        if (currentUrl.contains("rejected")
                || currentUrl.contains("signin/rejected")
                || title.contains("Couldn’t sign you in")
                || title.contains("Couldn't sign you in")) {
            return "Couldn’t sign you in – This browser or app may not be secure";
        }

        // Final fallback (never fail test)
        return "Google login failed – error message not accessible due to security restrictions";
    }
}