package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;

public class HomePage {

    private WebDriver driver;
    private WaitUtils wait;
    private Actions actions;
    private JavascriptExecutor js;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WaitUtils(driver);
        this.actions = new Actions(driver);
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

//    PARENT MENUS
    @FindBy(xpath = "//*[@id=\"headerNewVNavWrap\"]/nav/ul/li[3]/span")
    private WebElement newBikesMenu;

    @FindBy(xpath = "//*[normalize-space()='MORE']")
    private WebElement more;

    @FindBy(xpath = "//header//a[normalize-space()='Used Cars']")
    private WebElement usedCarsMenu;

//    SUB MENUS
    @FindBy(xpath = "//*[@id=\"headerNewVNavWrap\"]/nav/ul/li[3]/ul/li[4]/a")
    private WebElement upcomingBikesLink;

    @FindBy(xpath = "//a[normalize-space()='Chennai']")
    private WebElement usedCarsChennaiLink;


    @FindBy(id = "forum_login_title_lg")
    private WebElement loginButton;

    @FindBy(xpath = "//span[contains(text(),'Google')]")
    private WebElement googleLoginButton;

//    ACTION METHODS
    public void navigateToUpcomingBikes() {
        wait.waitForElementVisible(newBikesMenu);
        actions.moveToElement(newBikesMenu)
                .pause(700)
                .perform();
        wait.waitForElementVisible(upcomingBikesLink);
        js.executeScript("arguments[0].click();", upcomingBikesLink);
    }

    public void navigateToUsedCarsInChennai() {
        wait.waitForElementVisible(more);
        actions.moveToElement(more)
                .pause(700)
                .moveToElement(usedCarsMenu)
                .perform();
        wait.waitForElementVisible(usedCarsChennaiLink);
        js.executeScript("arguments[0].click();", usedCarsChennaiLink);
    }

//    Google Login
    public void clickGoogleLogin() {
        wait.waitForElementVisible(loginButton).click();
        wait.waitForElementVisible(googleLoginButton).click();
    }
}
