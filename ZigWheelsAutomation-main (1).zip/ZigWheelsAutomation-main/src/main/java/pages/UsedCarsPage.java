package pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;
import utils.ApacheUtils;

public class UsedCarsPage {
    private WebDriver driver;
    private WaitUtils wait;

    public UsedCarsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

//    Popular used car models
    @FindBy(xpath = "//div/ul[@class='zw-sr-secLev usedCarMakeModelList popularModels ml-20 mt-10']/li/label")
    private List<WebElement> popularCarModels;

//    Page Actions
//    Get list of popular used car models in Chennai
    public List<String> getPopularUsedCarModels() {
        ApacheUtils ap = new ApacheUtils("Popular Used Cars in Chennai");
        waitForPageToLoad();
        scrollDown();

        List<String> carModelList = new ArrayList<>();
        System.out.println("---- Popular Used Cars in Chennai ----");
        int rownum = 2;
        int colnum = 0;
        ap.writeXL("POPULAR CAR MODELS USED IN CHENNAI",0,0);
        for (WebElement model : popularCarModels) {
            String carName = model.getText();
            ap.writeXL(carName,rownum++,colnum);
            carModelList.add(carName);
            System.out.println(carName);
        }
//        ap.saveAndClose("C:\\Users\\2487729\\IdeaProjects\\ZigWheelsAutomation\\src\\main\\resources\\UsedCars.xlsx");
        String filePath = System.getProperty("user.dir") + "/src/main/resources/UsedCars.xlsx";
        ap.saveAndClose(filePath);
        return carModelList;
    }

//    Scroll down to load all elements
    private void scrollDown() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,800)");
    }

//    Simple page load wait
    private void waitForPageToLoad() {
        wait.waitForTitleContains("Used Cars");
    }
}
