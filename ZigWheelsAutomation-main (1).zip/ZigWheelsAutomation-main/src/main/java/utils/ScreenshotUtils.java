package utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotUtils {
    // Base directory for screenshots
    private static final String SCREENSHOT_PATH =
            System.getProperty("user.dir") + "/src/main/resources/screenshots/";

    /**
     * Capture screenshot with test name
     * @param driver   WebDriver instance
     * @param testName Name of the test
     * @return screenshot file path
     */
    public static String captureScreenshot(WebDriver driver, String testName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String screenshotName = testName + "_" + timestamp + ".png";
        File sourceFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File destinationFile = new File(SCREENSHOT_PATH + screenshotName);

        try {
            FileUtils.copyFile(sourceFile, destinationFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return destinationFile.getAbsolutePath();
    }

    /**
     * Capture screenshot with custom file name
     * @param driver   WebDriver instance
     * @param fileName Screenshot file name
     */
    public static void captureScreenshotWithName(WebDriver driver, String fileName) {
        File sourceFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File destinationFile = new File(SCREENSHOT_PATH + fileName + ".png");
        try {
            FileUtils.copyFile(sourceFile, destinationFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
