package utils;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ApacheUtils {
    public Object save;
    private Workbook workbook;
    private XSSFSheet sheet;

    public ApacheUtils(String sheetName){
        workbook = new XSSFWorkbook();
        sheet = (XSSFSheet) workbook.createSheet(sheetName);
    }

    public void writeXL(String data, int rownum, int colnum){
        XSSFRow row = sheet.getRow(rownum);
        if(row==null){
                row = sheet.createRow(rownum);
        }
        XSSFCell cell = row.createCell(colnum);
        cell.setCellValue(data) ;
    }

    public void saveAndClose(String filePath) {
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            workbook.write(fos);
            workbook.close();
            System.out.println("Excel file saved successfully at: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}