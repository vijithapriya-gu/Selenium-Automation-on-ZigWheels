package base;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import utils.BrowserFactory;
import utils.ScreenshotUtils;

public class baseTest {
    protected WebDriver driver;
    private static final String BROWSER = "chrome";
    private static final String BASE_URL = "https://www.zigwheels.com";

//    This method runs BEFORE EACH @Test method, Browser is launched fresh for every test
    @BeforeMethod
    public void setUp() {
        driver = BrowserFactory.initBrowser(BROWSER);
        driver.get(BASE_URL);
        System.out.println("Browser launched for test");
    }

//    This method runs AFTER EACH @Test method, Browser is closed after test execution
    @AfterMethod
    public void tearDown(ITestResult result) {
        if (ITestResult.FAILURE == result.getStatus()) {
            ScreenshotUtils.captureScreenshot(driver, result.getName());
        }
        BrowserFactory.quitBrowser();
        System.out.println("Browser closed after test");
    }
}