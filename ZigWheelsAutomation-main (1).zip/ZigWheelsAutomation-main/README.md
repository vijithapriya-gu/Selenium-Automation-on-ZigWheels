# ZigWheels Automation Testing Framework

![Language](https://img.shields.io/badge/Language-Java-orange)
![Automation](https://img.shields.io/badge/Automation-Selenium-green)
![Build](https://img.shields.io/badge/Build-Maven-blue)
![Status](https://img.shields.io/badge/Status-Private-lightgrey)
![License](https://img.shields.io/badge/License-MIT-yellow)

---

## Project Overview

**ZigWheelsAutomation** is a Selenium-based test automation framework developed to automate and validate key functionalities of the **ZigWheels** web application.  
The framework is designed using **Java**, follows a **modular and scalable structure**, and supports maintainable automated testing practices.

---

## Tech Stack

- **Programming Language:** Java
- **Automation Tool:** Selenium WebDriver
- **Build Tool:** Maven
- **Test Framework:** TestNG
- **Reporting:** ApachePOI
- **Version Control Tool & Platform:** Git & GitHub

---

## Project Structure

ZigWheelsAutomation
├── .idea/                         
├── .mvn/
├── src
│   ├── main
│   │   └── java
│   │       ├── base
│   │       │   └── BaseTest.java
│   │       ├── pages
│   │       │   ├── HomePage.java
│   │       │   ├── LoginPage.java
│   │       │   ├── UpcomingBikesPage.java
│   │       │   └── UsedCarsPage.java
│   │       └── utils
│   │           ├── BrowserFactory.java
│   │           ├── ScreenshotUtils.java
│   │           └── WaitUtils.java
│   └── test
│       └── java
│           └── tests
│               ├── UpcomingBikesTest.java
│               ├── UsedCarsTest.java
│               └── LoginTest.java
├── testng.xml                     
├── pom.xml                        
└── README.md

---

## Key Features

- Selenium WebDriver based UI automation
- Page Object Model for reusable and maintainable code
- Maven for build and dependency management
- Centralized browser management
- Explicit waits and screenshot capture utilities
- Easy integration with CI/CD tools

---

## Test Scenarios Covered

- ✅ Identify upcoming Honda bikes having price <4 Lakhs and capture details
- ✅ Validate used popular models cars of available in Chennai
- ✅ Perform negative login validation using Google Sign‑In

---

## Testings Performed
- Functional Testing
- UI Testing
- Regression Testing
- Data Validation Testing
- Negative Testing
- Smoke Testing
- Automation Testing
- Manual Testing

---

## How to Run the Tests

### Prerequisites
- Java JDK 8 or above
- Maven installed
- Chrome / Firefox browser
- IDE (IntelliJ IDEA / Eclipse)

### ▶ Execution Command
```bash
mvn clean test